# space-game
useless space game created with pygame in 20 minutes

1) install pygame
2) group all the files into a folder
3) run main.py
4) it should work yea
